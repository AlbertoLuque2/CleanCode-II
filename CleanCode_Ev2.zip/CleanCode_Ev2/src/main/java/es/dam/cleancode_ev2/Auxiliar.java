
package es.dam.cleancode_ev2;

public class Auxiliar extends Trabajador {
    private String tarea;    

    public Auxiliar(String nombre, int edad, int salarioBase, String tarea) {
        super(nombre, edad, salarioBase);
        this.tarea = tarea;
    }

    public Auxiliar(String tarea) {
        super();
        tarea = "";
    }

    public String getTarea() {
        return tarea;
    }

    public void setTarea(String tarea) {
        this.tarea = tarea;
    }

    @Override
    public String toString() {
        return "Auxiliar{" + "tarea=" + tarea + '}';
    }
}
