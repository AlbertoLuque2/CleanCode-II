
package es.dam.cleancode_ev2;

import java.util.ArrayList;
import java.util.List;

public class CleanCode_Ev2 {

    public static void main(String[] args) {
        // Creo objetos de Auxiliar y Repartidor
        Auxiliar auxiliar = new Auxiliar("Juanan", 21, 350, "Atender Mesas");
        Repartidor repartidor = new Repartidor("Alberto", 20, 400, "Moto", 210);
        

        // Imprimir información
        System.out.println("Auxiliar: " + auxiliar.getNombre() + ", Tarea: " + auxiliar.getTarea());
        System.out.println("Repartidor: " + repartidor.getNombre() + ", Vehículo: " + repartidor.getVehiculo());
        
        //Salario Calculado
        System.out.println("Salario calculado del Auxiliar:" +auxiliar.calculoSalario());
        System.out.println("Salario calculado del Repartidor:" +repartidor.calculoSalario());
        
        
        
        // BLOQUE BLOQUE IV: objetos y estructurads de datos

        //OBJETOS EN JAVA:
        Trabajador trabajador = new Trabajador("Noelia", 35, 1800);
        //Atributos del objeto
        String nombre = trabajador.getNombre();
        int edad = trabajador.getEdad();
        double salarioBase = trabajador.getSalarioBase();
        
        //ESTRUCTURA DE DATOS;
        // Creo una lista de repartidores
        List<Repartidor> listaRepartidores = new ArrayList<>();
        //Los agrego a una lista
        Repartidor repartidor1 = new Repartidor("Paco", 28, 2000, "Bicicleta", 15);
        Repartidor repartidor2 = new Repartidor("Nerea", 22, 2200, "Moto", 25);
        
        listaRepartidores.add(repartidor1);
        listaRepartidores.add(repartidor2);

        //HERENCIA Y POLIMOSRFISMO:
        // Crear una lista de trabajadores como repartidores
        List<Trabajador> listaTrabajadores = new ArrayList<>();
        listaTrabajadores.add(new Trabajador("Cristian", 30, 2500));
        listaTrabajadores.add(new Repartidor("Dani", 25, 2000, "Moto", 18));
        //calcular salarios
        for (Trabajador t : listaTrabajadores) {
            System.out.println(t.getNombre() + " - Salario: " + t.calculoSalario());
        }

        
        // Bloque V: Manejo de Errores

        // Imprimo la  información y caluclo su salario de trabajador y repartidor
        System.out.println("Trabajador: " + trabajador.getNombre() + ", Edad: " + trabajador.getEdad());
        System.out.println("Salario Base: " + trabajador.getSalarioBase());
        System.out.println("Salario Total: " + trabajador.calculoSalario());

        System.out.println("\nRepartidor: " + repartidor.getNombre() + ", Edad: " + repartidor.getEdad());
        System.out.println("Vehículo: " + repartidor.getVehiculo());
        System.out.println("Número de Pedidos: " + repartidor.getNumPedidos());
        System.out.println("Salario Total: " + repartidor.calculoSalario());
        
        
        
        
        
        
        
        
        
        
        
    }
}
