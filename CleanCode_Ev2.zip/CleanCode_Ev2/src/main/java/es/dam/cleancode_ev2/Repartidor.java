
package es.dam.cleancode_ev2;

public class Repartidor extends Trabajador {
    private String vehiculo;
    private int numPedidos;

    public Repartidor(String nombre, int edad, int salarioBase,String vehiculo, int numPedidos) {
        super(nombre, edad, salarioBase);
        if (numPedidos < 0) {
            throw new IllegalArgumentException("El número de pedidos no puede ser negativo.");
        }
        this.vehiculo = vehiculo;
        this.numPedidos = numPedidos;
    }

    public Repartidor() {
        super();
        vehiculo = "";
        numPedidos = 0;
    }

    public String getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(String vehiculo) {
        this.vehiculo = vehiculo;
    }

    public int getNumPedidos() {
        return numPedidos;
    }

    public void setNumPedidos(int numPedidos) {
        this.numPedidos = numPedidos;
    }

    @Override
    public String toString() {
        return "Repartidor{" + "vehiculo=" + vehiculo + ", numPedidos=" + numPedidos + '}';
    }
    public double calcularSalario() {
        
        return super.calculoSalario() + (numPedidos * 0.28); 
    }

}
