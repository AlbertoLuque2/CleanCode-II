
package es.dam.cleancode_ev2;


public class Trabajador {
    private String nombre;
    private int edad;
    private int salarioBase;

    public Trabajador(String nombre, int edad, int salarioBase) {
        this.nombre = nombre;
        this.edad = edad;
        this.salarioBase = salarioBase;
    }
    
    public Trabajador(){
        nombre = "";
        edad = 0;
        salarioBase = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(int salarioBase) {
        this.salarioBase = salarioBase;
    }

    @Override
    public String toString() {
        return "Trabajador{" + "nombre=" + nombre + ", edad=" + edad + ", salarioBase=" + salarioBase + '}';
    }
  
    public double calculoSalario(){
        if (salarioBase < 0) {
            throw new IllegalStateException("El salario base no puede ser negativo.");
        }
        return salarioBase;
    }
}