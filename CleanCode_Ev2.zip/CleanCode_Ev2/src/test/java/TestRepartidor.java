import es.dam.cleancode_ev2.Repartidor;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestRepartidor {

    @Test
    void testCalcularSalarioRepartidor() {
        Repartidor repartidor = new Repartidor("Juan", 30, 2500, "Moto", 20);

        assertEquals(2500.0 + (20 * 0.28), repartidor.calculoSalario(), 0.001);
    }
}
