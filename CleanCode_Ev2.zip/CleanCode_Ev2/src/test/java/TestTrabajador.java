import es.dam.cleancode_ev2.Trabajador;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestTrabajador {

    @Test
    void testCalcularSalarioTrabajador() {
        Trabajador trabajador = new Trabajador("Pedro", 28, 2000);

        assertEquals(2000.0, trabajador.calculoSalario(), 0.001);
    }
}
